#! /bin/bash

g++  -I/usr/local/include/opencv4 `pkg-config --libs opencv4` -Iinclude -o trackBodyMarkers src/*.cpp
